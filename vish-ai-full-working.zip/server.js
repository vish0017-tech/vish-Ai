import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";
dotenv.config();
const app=express(), port=process.env.PORT||3000;
const __dirname=path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({limit:"10mb"})); app.use(express.static(path.join(__dirname,"public")));
const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
app.post("/api/chat",async(req,res)=>{
  try{
    const messages=Array.isArray(req.body.messages)?req.body.messages:[];
    const input=messages.map(m=>({role:m.role,content:String(m.content)}));
    const r=await client.responses.create({
      model:process.env.OPENAI_MODEL||"gpt-5.6-luna",
      instructions:"You are Vish AI, a helpful, accurate, friendly general-purpose AI assistant. Answer clearly and directly. Use markdown when useful. Never claim to be ChatGPT or OpenAI; you are Vish AI.",
      input
    });
    res.json({text:r.output_text||"I couldn't generate a response."});
  }catch(e){console.error(e);res.status(500).json({error:"AI request failed. Check your API key, model, and server logs."});}
});
app.listen(port,()=>console.log(`Vish AI running at http://localhost:${port}`));